var files_dup =
[
    [ "html", "dir_2dae0a562653f78d59931f0e4b070746.html", "dir_2dae0a562653f78d59931f0e4b070746" ],
    [ "admin.php", "admin_8php.html", "admin_8php" ],
    [ "api_order.php", "api__order_8php.html", "api__order_8php" ],
    [ "index.php", "index_8php.html", "index_8php" ],
    [ "login.php", "login_8php.html", "login_8php" ],
    [ "logout.php", "logout_8php.html", "logout_8php" ],
    [ "orders.php", "orders_8php.html", "orders_8php" ],
    [ "profile.php", "profile_8php.html", "profile_8php" ],
    [ "register.php", "register_8php.html", "register_8php" ],
    [ "script.js", "script_8js.html", null ],
    [ "style.css", "style_8css.html", null ]
];