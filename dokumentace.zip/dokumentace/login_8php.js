var login_8php =
[
    [ "$chybaLogin", "login_8php.html#a3212cccd856292c577cb717b893b2284", null ],
    [ "$userValue", "login_8php.html#ad9153eb35be889e1e9eb7cf1c68e132c", null ],
    [ "endif", "login_8php.html#a47ed2903024dd34bddb75e507e0c6f9c", null ]
];