var namespaces_dup =
[
    [ "GastroV2", "namespace_gastro_v2.html", null ]
];