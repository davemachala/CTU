var logout_8php =
[
    [ "$_SESSION", "logout_8php.html#a5f545b9684799a00f7a14442205b98e3", null ]
];