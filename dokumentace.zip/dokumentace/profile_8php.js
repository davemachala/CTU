var profile_8php =
[
    [ "$chyby", "profile_8php.html#a0bdcd75fd4162d8e2ca909e437acb8f3", null ],
    [ "$uspech", "profile_8php.html#ad820b032eb30e559d523acaf50744e3f", null ],
    [ "class", "profile_8php.html#a230ecd2268c3a48a90572959392680ff", null ],
    [ "endif", "profile_8php.html#ac4a7daf7758a3bc2e992d95346e9ebf0", null ]
];