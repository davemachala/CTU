var searchData=
[
  ['menu_0',['Správa menu',['../index.html#autotoc_md10',1,'']]],
  ['menu_20a_20objednávky_1',['Procházení menu a objednávky',['../index.html#autotoc_md6',1,'']]],
  ['modely_2',['Datové modely',['../index.html#autotoc_md17',1,'']]]
];
