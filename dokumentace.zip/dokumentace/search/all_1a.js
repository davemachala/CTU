var searchData=
[
  ['✅_20implementované_0',['✅ Implementované',['../index.html#autotoc_md36',1,'']]]
];
