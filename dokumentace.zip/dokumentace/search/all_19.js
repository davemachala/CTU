var searchData=
[
  ['řazení_0',['Funkcionalita řazení',['../index.html#autotoc_md31',1,'']]]
];
