var searchData=
[
  ['readme_2emd_0',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['redirect_20get_1',['POST-Redirect-GET',['../index.html#autotoc_md21',1,'']]],
  ['register_20php_2',['register.php',['../index.html#autotoc_md25',1,'']]],
  ['register_2ephp_3',['register.php',['../register_8php.html',1,'']]],
  ['register_5f8php_2ejs_4',['register_8php.js',['../register__8php_8js.html',1,'']]],
  ['registrace_5',['Registrace',['../index.html#autotoc_md4',1,'']]],
  ['registrace_6',['Přihlášení a registrace',['../index.html#autotoc_md3',1,'']]],
  ['restaurace_20u_20feláka_20webová_20aplikace_7',['Restaurace U FELáka - Webová aplikace',['../index.html',1,'']]],
  ['role_8',['Uživatelské role',['../index.html#autotoc_md16',1,'']]]
];
