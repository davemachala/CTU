var searchData=
[
  ['objednávek_0',['Správa objednávek',['../index.html#autotoc_md11',1,'']]],
  ['objednávky_1',['Procházení menu a objednávky',['../index.html#autotoc_md6',1,'']]],
  ['obsah_2',['Obsah',['../index.html#autotoc_md1',1,'']]],
  ['ochrana_3',['XSS ochrana',['../index.html#autotoc_md20',1,'']]],
  ['operace_4',['Běžné operace',['../index.html#autotoc_md33',1,'']]]
];
