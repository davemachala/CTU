var searchData=
[
  ['objednávek_0',['Správa objednávek',['../index.html#autotoc_md11',1,'']]],
  ['objednávky_1',['Procházení menu a objednávky',['../index.html#autotoc_md6',1,'']]],
  ['obsah_2',['Obsah',['../index.html#autotoc_md1',1,'']]],
  ['ochrana_3',['XSS ochrana',['../index.html#autotoc_md20',1,'']]],
  ['operace_4',['Běžné operace',['../index.html#autotoc_md33',1,'']]],
  ['orders_2ephp_5',['orders.php',['../orders_8php.html',1,'']]],
  ['orders_5f8php_2ejs_6',['orders_8php.js',['../orders__8php_8js.html',1,'']]]
];
