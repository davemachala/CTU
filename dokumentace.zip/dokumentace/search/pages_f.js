var searchData=
[
  ['script_20js_0',['script.js',['../index.html#autotoc_md30',1,'']]],
  ['serveru_1',['Validace na serveru',['../index.html#autotoc_md22',1,'']]],
  ['soubory_2',['Klíčové soubory',['../index.html#autotoc_md23',1,'']]],
  ['správa_20menu_3',['Správa menu',['../index.html#autotoc_md10',1,'']]],
  ['správa_20objednávek_4',['Správa objednávek',['../index.html#autotoc_md11',1,'']]],
  ['správa_20profilu_5',['Správa profilu',['../index.html#autotoc_md7',1,'']]],
  ['správa_20uživatelů_6',['Správa uživatelů',['../index.html#autotoc_md9',1,'']]],
  ['stránkování_7',['Stránkování',['../index.html#autotoc_md32',1,'']]],
  ['struktura_20projektu_8',['Struktura projektu',['../index.html#autotoc_md14',1,'']]]
];
