var searchData=
[
  ['implementované_0',['✅ Implementované',['../index.html#autotoc_md36',1,'']]],
  ['index_20php_1',['index.php',['../index.html#autotoc_md28',1,'']]],
  ['index_2ejs_2',['index.js',['../index_8js.html',1,'']]],
  ['index_2ephp_3',['index.php',['../index_8php.html',1,'']]],
  ['index_5f8php_2ejs_4',['index_8php.js',['../index__8php_8js.html',1,'']]]
];
