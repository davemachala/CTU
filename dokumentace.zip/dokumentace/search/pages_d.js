var searchData=
[
  ['přihlášení_0',['Přihlášení',['../index.html#autotoc_md5',1,'']]],
  ['přihlášení_20a_20registrace_1',['Přihlášení a registrace',['../index.html#autotoc_md3',1,'']]],
  ['php_2',['php',['../index.html#autotoc_md27',1,'admin.php'],['../index.html#autotoc_md29',1,'api_order.php'],['../index.html#autotoc_md28',1,'index.php'],['../index.html#autotoc_md24',1,'login.php'],['../index.html#autotoc_md26',1,'profile.php'],['../index.html#autotoc_md25',1,'register.php']]],
  ['post_20redirect_20get_3',['POST-Redirect-GET',['../index.html#autotoc_md21',1,'']]],
  ['poznámky_20k_20vývojářům_4',['Poznámky k vývojářům',['../index.html#autotoc_md40',1,'']]],
  ['procházení_20menu_20a_20objednávky_5',['Procházení menu a objednávky',['../index.html#autotoc_md6',1,'']]],
  ['profile_20php_6',['profile.php',['../index.html#autotoc_md26',1,'']]],
  ['profilu_7',['Správa profilu',['../index.html#autotoc_md7',1,'']]],
  ['programátorská_20dokumentace_8',['Programátorská dokumentace',['../index.html#autotoc_md13',1,'']]],
  ['projektu_9',['Struktura projektu',['../index.html#autotoc_md14',1,'']]]
];
