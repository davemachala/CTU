var searchData=
[
  ['xss_20ochrana_0',['XSS ochrana',['../index.html#autotoc_md20',1,'']]]
];
