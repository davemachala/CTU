var searchData=
[
  ['na_20serveru_0',['Validace na serveru',['../index.html#autotoc_md22',1,'']]]
];
