var searchData=
[
  ['a_20objednávky_0',['Procházení menu a objednávky',['../index.html#autotoc_md6',1,'']]],
  ['a_20registrace_1',['Přihlášení a registrace',['../index.html#autotoc_md3',1,'']]],
  ['admin_20php_2',['admin.php',['../index.html#autotoc_md27',1,'']]],
  ['administrace_3',['Administrace',['../index.html#autotoc_md8',1,'']]],
  ['api_5forder_20php_4',['api_order.php',['../index.html#autotoc_md29',1,'']]],
  ['aplikace_5',['Restaurace U FELáka - Webová aplikace',['../index.html',1,'']]],
  ['architektura_6',['Architektura',['../index.html#autotoc_md15',1,'']]]
];
