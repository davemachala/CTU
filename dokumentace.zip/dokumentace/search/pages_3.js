var searchData=
[
  ['feláka_20webová_20aplikace_0',['Restaurace U FELáka - Webová aplikace',['../index.html',1,'']]],
  ['funkcionalita_20řazení_1',['Funkcionalita řazení',['../index.html#autotoc_md31',1,'']]],
  ['funkcionality_2',['Funkcionality',['../index.html#autotoc_md35',1,'']]]
];
