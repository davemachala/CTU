var searchData=
[
  ['běžné_20operace_0',['Běžné operace',['../index.html#autotoc_md33',1,'']]],
  ['bezpečnost_1',['Bezpečnost',['../index.html#autotoc_md18',1,'']]]
];
