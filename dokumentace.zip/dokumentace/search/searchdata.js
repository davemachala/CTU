var indexSectionsWithContent =
{
  0: "$_abcdefghijklmnoprstuvwxř✅",
  1: "g",
  2: "acdfijlmnoprstv",
  3: "$_ce",
  4: "abdfghijklmnoprstuvwxř✅"
};

var indexSectionNames =
{
  0: "all",
  1: "namespaces",
  2: "files",
  3: "variables",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Namespaces",
  2: "Files",
  3: "Variables",
  4: "Pages"
};

