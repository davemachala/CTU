var searchData=
[
  ['vývojářům_0',['Poznámky k vývojářům',['../index.html#autotoc_md40',1,'']]],
  ['validace_20na_20serveru_1',['Validace na serveru',['../index.html#autotoc_md22',1,'']]]
];
