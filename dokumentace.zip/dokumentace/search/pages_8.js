var searchData=
[
  ['k_20vývojářům_0',['Poznámky k vývojářům',['../index.html#autotoc_md40',1,'']]],
  ['klíčové_20soubory_1',['Klíčové soubory',['../index.html#autotoc_md23',1,'']]]
];
