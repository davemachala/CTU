var searchData=
[
  ['implementované_0',['✅ Implementované',['../index.html#autotoc_md36',1,'']]],
  ['index_20php_1',['index.php',['../index.html#autotoc_md28',1,'']]]
];
