var searchData=
[
  ['tabs_2ecss_0',['tabs.css',['../tabs_8css.html',1,'']]]
];
