var searchData=
[
  ['datové_20modely_0',['Datové modely',['../index.html#autotoc_md17',1,'']]],
  ['dokumentace_1',['dokumentace',['../index.html#autotoc_md13',1,'Programátorská dokumentace'],['../index.html#autotoc_md2',1,'Uživatelská dokumentace']]]
];
