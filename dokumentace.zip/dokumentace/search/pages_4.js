var searchData=
[
  ['get_0',['POST-Redirect-GET',['../index.html#autotoc_md21',1,'']]]
];
