var searchData=
[
  ['menu_0',['Správa menu',['../index.html#autotoc_md10',1,'']]],
  ['menu_20a_20objednávky_1',['Procházení menu a objednávky',['../index.html#autotoc_md6',1,'']]],
  ['menu_2ejs_2',['menu.js',['../menu_8js.html',1,'']]],
  ['menudata_2ejs_3',['menudata.js',['../menudata_8js.html',1,'']]],
  ['modely_4',['Datové modely',['../index.html#autotoc_md17',1,'']]]
];
