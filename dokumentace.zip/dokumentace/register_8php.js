var register_8php =
[
    [ "$chyby", "register_8php.html#a0bdcd75fd4162d8e2ca909e437acb8f3", null ],
    [ "$userValue", "register_8php.html#ad9153eb35be889e1e9eb7cf1c68e132c", null ],
    [ "$uspech", "register_8php.html#ad820b032eb30e559d523acaf50744e3f", null ],
    [ "endif", "register_8php.html#a7016be5293ff0bdfbb70171716a49c22", null ]
];