var api__order_8php =
[
    [ "$aktualniObjednavky", "api__order_8php.html#a3b96e069d305bb63d509ad176a3d8867", null ],
    [ "$aktualniObjednavky", "api__order_8php.html#a6847b2faee7ddb86ec730a99261f9aa8", null ],
    [ "$celkovaCena", "api__order_8php.html#a14163480887ab168bd8b7b5ddd44029d", null ],
    [ "$dataOdKlienta", "api__order_8php.html#abc12e23ca82d7ae44e71bca40602ca94", null ],
    [ "$finalniPolozky", "api__order_8php.html#a9f9769eba66b428f4e7242860741cd0c", null ],
    [ "$inputJSON", "api__order_8php.html#a5839027e30f35c357270d56236d6dbf6", null ],
    [ "$menu", "api__order_8php.html#a44b0c947ca193a7764153898f5336910", null ],
    [ "$novaObjednavka", "api__order_8php.html#a7345a80b41462e860ddf29536b4a85d7", null ],
    [ "$souborOrders", "api__order_8php.html#addb1362d20742bebd8ea8f2906dcc1c9", null ],
    [ "else", "api__order_8php.html#aa25f08b9b4a496e2d761c86dec0a4fb3", null ]
];