var index =
[
    [ "Obsah", "index.html#autotoc_md1", null ],
    [ "Uživatelská dokumentace", "index.html#autotoc_md2", [
      [ "Přihlášení a registrace", "index.html#autotoc_md3", [
        [ "Registrace", "index.html#autotoc_md4", null ],
        [ "Přihlášení", "index.html#autotoc_md5", null ]
      ] ],
      [ "Procházení menu a objednávky", "index.html#autotoc_md6", null ],
      [ "Správa profilu", "index.html#autotoc_md7", null ],
      [ "Administrace", "index.html#autotoc_md8", [
        [ "Správa uživatelů", "index.html#autotoc_md9", null ],
        [ "Správa menu", "index.html#autotoc_md10", null ],
        [ "Správa objednávek", "index.html#autotoc_md11", null ]
      ] ]
    ] ],
    [ "Programátorská dokumentace", "index.html#autotoc_md13", [
      [ "Struktura projektu", "index.html#autotoc_md14", null ],
      [ "Architektura", "index.html#autotoc_md15", [
        [ "Uživatelské role", "index.html#autotoc_md16", null ],
        [ "Datové modely", "index.html#autotoc_md17", null ]
      ] ],
      [ "Bezpečnost", "index.html#autotoc_md18", [
        [ "Hasování hesel", "index.html#autotoc_md19", null ],
        [ "XSS ochrana", "index.html#autotoc_md20", null ],
        [ "POST-Redirect-GET", "index.html#autotoc_md21", null ],
        [ "Validace na serveru", "index.html#autotoc_md22", null ]
      ] ],
      [ "Klíčové soubory", "index.html#autotoc_md23", [
        [ "login.php", "index.html#autotoc_md24", null ],
        [ "register.php", "index.html#autotoc_md25", null ],
        [ "profile.php", "index.html#autotoc_md26", null ],
        [ "admin.php", "index.html#autotoc_md27", null ],
        [ "index.php", "index.html#autotoc_md28", null ],
        [ "api_order.php", "index.html#autotoc_md29", null ],
        [ "script.js", "index.html#autotoc_md30", null ]
      ] ],
      [ "Funkcionalita řazení", "index.html#autotoc_md31", null ],
      [ "Stránkování", "index.html#autotoc_md32", null ],
      [ "Běžné operace", "index.html#autotoc_md33", null ]
    ] ],
    [ "Funkcionality", "index.html#autotoc_md35", [
      [ "✅ Implementované", "index.html#autotoc_md36", null ]
    ] ],
    [ "Technologie", "index.html#autotoc_md38", null ],
    [ "Poznámky k vývojářům", "index.html#autotoc_md40", null ]
];